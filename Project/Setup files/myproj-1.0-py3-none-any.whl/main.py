import project
import gui

def main():
    # Call the functions from both files
    gui.function1()
    # function2()

if __name__ == "__main__":
    main()
